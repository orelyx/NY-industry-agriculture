
import pandas as pd


def combine(mfg, cons, ag, mining):
  """
  Combine energy estimates by sector.

  Returns a dataframe indexed by year
  """
